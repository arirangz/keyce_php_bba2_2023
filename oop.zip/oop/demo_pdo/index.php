<?php

$pdo = new PDO('mysql:dbname=demo;host=localhost;charset=utf8mb4', 'root', '');

$query = $pdo->prepare("SELECT * FROM user");
$query->execute();
$users = $query->fetchAll(PDO::FETCH_ASSOC);

var_dump($users);
?>