<?php

$pdo = new PDO('mysql:dbname=demo;host=localhost;charset=utf8mb4', 'root', '');

$user_id = $_GET['id'];

$query = $pdo->prepare("SELECT * FROM user WHERE id = :id");
$query->bindValue(':id', $user_id, PDO::PARAM_INT);
$query->execute();
$user = $query->fetch(PDO::FETCH_ASSOC);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>User information:</h1>
    <p>First name: <?=$user['first_name']; ?></p>
    <p>Last name: <?=$user['last_name']; ?></p>
    <p>Email: <?=$user['email']; ?></p>
</body>
</html>